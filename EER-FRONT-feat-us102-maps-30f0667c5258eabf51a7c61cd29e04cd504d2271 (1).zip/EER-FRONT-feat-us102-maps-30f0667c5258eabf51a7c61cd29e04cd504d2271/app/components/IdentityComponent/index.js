import React from 'react';
import TextField from 'material-ui/TextField';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';
import PropTypes from 'prop-types';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton/RaisedButton';

const styles = {
  radioStyle: {
    marginBottom: '12px',
  },
  radioGroupStyle: {
    marginTop: '30px',
  },
  displayFlex: {
    display: 'flex',
  },
  margin: 12,
};
const style = {
  margin: 12,
};
this.state = {
  color_black: true
}
let bgColor = this.state.color_black ? "black" : "white";
let active=false;


const IdentityComponent = ({ onParticulariterClick2, onFieldChange, identityValues, onEventValFieldChange }) => (
  
  <div>
    <div style={styles.displayFlex}>
      <div>
       
      <RaisedButton label="PARTICULIER" 
                    style={{ visibility: identityValues.part ? 'visible': 'hidden'}}
                    onClick={ onParticulariterClick2} />
      </div>
      <div>
      <RaisedButton label="PROFESSIONNEL" style={style}  />
      </div>
    </div>
    <RadioButtonGroup name="sexe"
                      onChange={onFieldChange}
                      style={styles.radioGroupStyle}
                      valueSelected={identityValues.sexe}
                      fullWidth
    >
      <RadioButton
        value="0"
        label="Homme"
        style={styles.radioStyle}
      />
      <RadioButton
        value="1"
        label="Femme"
      />
    </RadioButtonGroup>
    <TextField
      name="lastName"
      floatingLabelText="Nom de famille"
      onChange={onFieldChange}
      value={identityValues.part}
      fullWidth
    />
    <TextField
      name="firstName"
      floatingLabelText="Prénom"
      onChange={onFieldChange}
      value={identityValues.firstName}
      fullWidth
    />
    <TextField
      name="dateOfBirth"
      hintText="Doit respecter le pattern: dd/MM/yyyy"
      floatingLabelText="Date de naissance"
      value={identityValues.dateOfBirth}
      onChange={onFieldChange}
      fullWidth
    />
    <TextField
      name="email"
      floatingLabelText="Email"
      onChange={onFieldChange}
      value={identityValues.email}
      fullWidth
    />
    <TextField
      name="tele"
      floatingLabelText="Num Tel"
      onChange={onFieldChange}
      value={identityValues.tele}
      fullWidth
    />
  </div>
  
);
IdentityComponent.propTypes = {
  onParticulariterClick: PropTypes.func.isRequired,
  onFieldChange: PropTypes.func.isRequired,
  onEventValFieldChange: PropTypes.func.isRequired,
  identityValues: PropTypes.object.isRequired,

};

export default IdentityComponent;
