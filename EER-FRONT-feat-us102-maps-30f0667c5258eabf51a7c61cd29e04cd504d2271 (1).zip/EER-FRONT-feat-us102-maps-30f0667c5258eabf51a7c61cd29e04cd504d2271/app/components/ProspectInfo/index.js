import React from 'react';
import { connect } from 'react-redux';
import TextField from 'material-ui/TextField';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';
import PropTypes from 'prop-types';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import { styles } from './styles';
import * as cv from '../../images/curriculum.svg';
import * as Regex from '../../utils/constants';
import * as FormConstante from '../../utils/constants'  
//import { Button } from 'reactstrap';
class ProspectInfo extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      lastName:'',
      firstName:'',
      email:'',
      tele:'',
      particularite:FormConstante.PROSPECT_FORM_PARTICULIER,
      particulier: true,
      professionel: false,
      isFirstNameValid:true,
      isLastNameValid:true,
      isEmailValid:true,
      isTelephoneValid:true,
    };
    
  }
  componentWillMount(){
    if (this.props.step.stepIndex==3) {
        this.setState({ particulier: true});
        this.setState({ professionel: true}); 
        this.setState({ isFirstNameValid: true}); 
        this.setState({ isLastNameValid: true}); 
        this.setState({ isEmailValid: true}); 
        this.setState({ isTelephoneValid: true});
        if (this.props.prospect) {
          this.setState({ lastName: this.props.prospect.lastName}); 
          this.setState({ firstName: this.props.prospect.firstName}); 
          this.setState({ email: this.props.prospect.email}); 
          this.setState({ tele: this.props.prospect.tele}); 
        }
    }
    
  

  }
  /**
   * when a component will unmount
   */
  componentWillUnmount(){}

  /**
   * catch error
   */
  componentDidCatch(error, info){}
/**
 * chose particularite
 */
  onParticulariteClick(part,prof) {
    this.setState({
      particulier: part,
      professionel: prof,
      particularite: part? FormConstante.PROSPECT_FORM_PARTICULIER :FormConstante.PROSPECT_FORM_PROFESSIONEL,
    });
    
  }

  /**
   * handler to validate a name
   */
  handleLastNameChange(event) {
    const valid = Regex.REGEX_PROSPECT_NAME.test(event.target.value)
    this.setState({ isLastNameValid: valid}); 
    if (valid) {
      this.setState({ lastName: event.target.value});
    }
  }
  /**
   * handler to validate a firstName
   */
  handleFirstNameChange(event) {
    const valid = Regex.REGEX_PROSPECT_FIRST_NAME.test(event.target.value)
    this.setState({ isFirstNameValid: valid}); 
    if (valid) {
      this.setState({ firstName: event.target.value});
    }
  }
  /**
   * handler to validate an email
   */ 
  handleEmailChange(event) {
    const valid = Regex.REGEX_PROSPECT_EMAIL.test(event.target.value);
    this.setState({ isEmailValid: valid}); 
    if (valid) {
      this.setState({ email: event.target.value});
    }
  }
  /**
   * handler to validate a phone number
   */
  handleTeleChange(event) {
    const valid = Regex.REGEX_PROSPECT_PHONE.test(event.target.value)
    this.setState({ isTelephoneValid: valid}); 
    if (valid) {
      this.setState({ tele: event.target.value});
    }
  }     
  /**
   * send date to parent component
   */
  validStep(){
      this.props.onValidateStep(this.state);
  }
 
    render() {
      return (

        <div style={styles.displayFlex}>
      
          <div style={styles.container.minWidth}>
          <img src={cv} style={styles.container.cv} alt="logo" />
          </div>
          <div>
            <div>
              <div>FAISONS CONNAISSANCE</div>
              <div>Quelques questions pour mieux vous connaitre</div>
            </div>
            <br></br>
              <div style={styles.displayFlex}>
                    <div style={styles.container.formProspect.part.marginRight}>
                        <RaisedButton label="PARTICULIER"               
                                      secondary={this.state.particulier}
                                      style={styles.bg}
                                      onClick={this.onParticulariteClick.bind(this,true,false)}   
                          />
              
                    </div>
                    <div>
                        <RaisedButton label="PROFESSIONNEL"  
                                      secondary={this.state.professionel}
                                      onClick={this.onParticulariteClick.bind(this,false,true)}    />
                    </div>
              </div>
                <div>
                      <TextField  name="lastName" 
                                  floatingLabelText="Mon Nom"
                                  defaultValue={this.props.prospect && this.props.step.stepIndex==3?this.props.prospect.lastName:""}
                                  errorText={!this.state.isLastNameValid? "Veuillez saisir un nom valide" :null}
                                  onChange={this.handleLastNameChange.bind(this)}/>
                </div>
                <div>
                      <TextField  name="firstName"
                                
                                  defaultValue={this.props.prospect&& this.props.step.stepIndex==3 ?this.props.prospect.firstName:""}
                                  floatingLabelText="Mon Prénom"
                                  errorText={!this.state.isFirstNameValid? "Veuillez saisir un prénom valide" :null}
                                  onChange={this.handleFirstNameChange.bind(this)}/>
                </div>
                <div>
                      <TextField  name="email" 
                                  defaultValue={this.props.prospect && this.props.step.stepIndex==3?this.props.prospect.email:""}
                                  floatingLabelText="Mon adresse email" 
                                  errorText={!this.state.isEmailValid? "Veuillez saisir un email valide" :null}
                                  onChange={this.handleEmailChange.bind(this)}/>
                </div>
                <div>
                      <TextField  name="tele"
                                  defaultValue={this.props.prospect && this.props.step.stepIndex==3 ?this.props.prospect.tele:""}  
                                  floatingLabelText="Mon téléphone"
                                  errorText={!this.state.isTelephoneValid? "Veuillez saisir un téléphone valide" :null}
                                  onChange={this.handleTeleChange.bind(this)}/>
                </div>
                <div>
                      
                </div>

               
               <div  style={styles.container.buttonChoseAgence}>

                <FlatButton label="Choisir mon agence" 
                            primary={true} 
                            onClick={this.validStep.bind(this)}
                            disabled={
                                      !this.state.isLastNameValid
                                      || !this.state.isFirstNameValid
                                      || !this.state.isEmailValid
                                      || !this.state.isTelephoneValid 
                                      || this.state.lastName.length==0                            
                                      || this.state.firstName.length==0
                                      || this.state.email.length==0
                                      || this.state.tele.length==0          
                                      }/>
          </div>
          </div>
         

          </div>

      );
    }

  }

ProspectInfo.propTypes = {
    onValidateStep: PropTypes.func.isRequired, 
};

export default ProspectInfo;

