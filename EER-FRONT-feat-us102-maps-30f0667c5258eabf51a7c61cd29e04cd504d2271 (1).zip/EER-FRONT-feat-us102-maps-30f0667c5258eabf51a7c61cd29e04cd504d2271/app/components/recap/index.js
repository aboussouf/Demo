import React from 'react';
import { connect } from 'react-redux';
import TextField from 'material-ui/TextField';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';
import ActionFavorite from 'material-ui/svg-icons/action/favorite';
import ActionFavoriteBorder from 'material-ui/svg-icons/action/favorite-border';
import PropTypes from 'prop-types';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import { styles } from './styles';
import DatePicker from 'material-ui/DatePicker';
import TimePicker from 'material-ui/TimePicker/TimePicker';
import Calendar from 'material-ui/DatePicker/Calendar';
import {List, ListItem} from 'material-ui/List';
import Toggle from 'material-ui/Toggle'; 

class Recap extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      boisson:'CAFE',
      cmdp:false,
      Toggled:'ON',
    };
    
    
  }
  
 /**
   * when a component will mount
   */

  componentWillMount(){
  }

  /**
   * when a component will unmount
   */
  componentWillUnmount(){

  }

  /**
   * catch error
   */
  componentDidCatch(error, info){

  }

  handleCheck(ev, checked) {
    console.log('event ',ev.target.value);
  }
  /**
   * send date to parent component
   */
  validStep(){
      this.props.onValidateStep(this.props.prospect);
    }

    handlePrevStep () {
      this.props.onPrevStep();
    }

    handleBoissonChange = event => {
       this.props.prospect.boisson=event.target.value;
    };

    handleCmdpToggle = (event) => {
      this.setState({cmdp:!this.state.cmdp});

      this.props.prospect.cmdp=!this.state.cmdp==true?1:0;
    }
    handleModifierInfo() {
      this.props.onChangeInfo(0);
    }
    render() {
      return (
        <div >
            <div>
               <p>Nom :  {this.props.prospect.lastName}  </p> 
               <p>Prénom :  {this.props.prospect.firstName}</p>  
               <p>tele :  {this.props.prospect.tele}  </p>  
               <p>email :  {this.props.prospect.email}  </p> 
               <p>Particulariter :  {this.props.prospect.typeProspect}  </p>   
               <p>date Rendez-vous :  {this.props.prospect.dateRdv}  </p>
               <p>heure Rendez-vous :  {this.props.prospect.heureRdv}  </p> 
               <p>mon agence :  {this.props.prospect.agence.name}  </p>  
               <p>adresse agence :  {this.props.prospect.agence.adresse}  </p>
               <p>Vous etes plutot</p>  
                <RadioButtonGroup name="boisson" defaultSelected={this.props.prospect.boisson} onChange={this.handleBoissonChange}>
                  <RadioButton
                      value="THE"
                      label="THE"
                      style={styles.radioButton}
                  />
                  <RadioButton
                    value="CAFE"
                    label="CAFE"
                    style={styles.radioButton}
                  />
                </RadioButtonGroup> 
                 <Toggle
                        label="J'accepte les conditions d'utilusations"
                        labelPosition="right"
                        style={styles.toggle}
                        onToggle={this.handleCmdpToggle}
                  />
            <RaisedButton label="Modifier" 
                          primary={true}
                         
                          onClick={this.handleModifierInfo.bind(this)}
                            />

            </div>
            <FlatButton label="RETOUR" 
                            primary={true} 
                            onClick={this.handlePrevStep.bind(this)}
                            />
          <FlatButton label="PRENDRE RENDEZ-VOUS" 
                            primary={true} 
                            onClick={this.validStep.bind(this)}
                            />  
          
        </div>
      );
    }

  }

  Recap.propTypes = {
    onValidateStep: PropTypes.func.isRequired,
    onPrevStep: PropTypes.func.isRequired,
    prospect: PropTypes.object.isRequired 
};

export default Recap;

