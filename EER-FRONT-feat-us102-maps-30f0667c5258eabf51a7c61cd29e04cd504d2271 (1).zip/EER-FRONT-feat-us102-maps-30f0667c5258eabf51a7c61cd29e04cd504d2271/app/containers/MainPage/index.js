import React from 'react';
import Header from 'components/Header';
import Sidebar from 'components/Sidebar';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import { connect } from 'react-redux';
import { makeSelectHeaderTitle } from 'store/selectors/Header';
import PropTypes from 'prop-types';
import { withRouter } from 'react-router-dom';

class MainPage extends React.Component {
  state = {
    isDrawerOpen: false,
  }
  onRequestChange = (val) => {
    this.setState({ isDrawerOpen: val });
  }
  onHeaderTitleClick = () => {
    (this.props.history).push('/');
  }
  handleHeaderLeftIconClick = () => {
    this.setState({ isDrawerOpen: !this.state.isDrawerOpen });
  }
  render() {
    return (
      <MuiThemeProvider>
        <div>
          <Header
            title='DIGITAL FACTORY'
         
            headerClick={this.onHeaderTitleClick}
          />
          <Sidebar
            open={this.state.isDrawerOpen}
            onRequestChange={this.onRequestChange}
            secondary={false}
          />
        </div>
      </MuiThemeProvider>
    );
  }
}

MainPage.propTypes = {
  headerTitle: PropTypes.string.isRequired,
  history: PropTypes.object.isRequired,
};
const mapStateToProps = (state) => ({
  headerTitle: makeSelectHeaderTitle()(state),
});
export default withRouter(connect(mapStateToProps, null)(MainPage));
