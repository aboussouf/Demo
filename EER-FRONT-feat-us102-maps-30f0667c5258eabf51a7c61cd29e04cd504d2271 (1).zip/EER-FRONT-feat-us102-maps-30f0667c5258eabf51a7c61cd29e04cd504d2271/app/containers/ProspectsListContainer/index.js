import React from 'react';
import PropTypes from 'prop-types';
import ProspectsList from 'components/ProspectsList';
import Paper from 'material-ui/Paper';
import { connect } from 'react-redux';
import { makeSelectProspectsList } from 'store/selectors/Prospects';
import { getProspectsList, deleteProspect } from 'store/actions/Prospects';

import { makeSelectAgencesList } from 'store/selectors/Geolocs';
import { getAgences, setAgences } from 'store/actions/Geolocs';

import FloatingActionButton from 'material-ui/FloatingActionButton';
import ContentAdd from 'material-ui/svg-icons/content/add';
import { withRouter } from 'react-router-dom';
import ConfirmationDialog from 'components/ConfirmationDialog';

const styles = {
  prospectsListContainerStyle: {
    width: '80%',
    margin: '0 auto',
    marginTop: '50px',
    padding: '50px',
    paddingBottom: '80px',
  },
  addButton: {
    float: 'right',
  },
};
export class ProspectsListContainer extends React.Component {
  state = {
    isConfirmationDialogOpen: false,
    prospectToDelete: null,
  }
  componentDidMount = () => {
    this.props.getProspectsList();

  }
  handleAddButtonClick = () => {
    (this.props.history).push('/signup');
  }
  handleProspectDeleteActionClick = (prospect) => () => {
    this.setState({
      ...this.state,
      isConfirmationDialogOpen: true,
      prospectToDelete: prospect,
    });
  }
  handleProspectDelete = () => {
    if (this.state.prospectToDelete) {
      this.props.deleteProspect(this.state.prospectToDelete);
      this.setState({
        ...this.state,
        isConfirmationDialogOpen: false,
        prospectToDelete: null,
      });
    }
  }
  handleConfirmationDialogCancel = () => {
    this.setState({
      ...this.state,
      isConfirmationDialogOpen: false,
    });
  }
  render() {
    return (
      <Paper style={styles.prospectsListContainerStyle} zDepth={3}>
        <ProspectsList
          prospects={this.props.prospects}
          handleDelete={this.handleProspectDeleteActionClick}
        />
        <FloatingActionButton style={styles.addButton} onClick={this.handleAddButtonClick}>
          <ContentAdd />
        </FloatingActionButton>
        <ConfirmationDialog
          open={this.state.isConfirmationDialogOpen}
          body={'Voulez-vous vraiment supprimer ce prospect ? cette action est irreversible.'}
          handleCancel={this.handleConfirmationDialogCancel}
          handleValidate={this.handleProspectDelete}
        />
      </Paper>
    );
  }
}

ProspectsListContainer.propTypes = {
  prospects: PropTypes.array,
  history: PropTypes.object.isRequired,
  getProspectsList: PropTypes.func.isRequired,
  deleteProspect: PropTypes.func.isRequired,

};

const mapDispatchToProps = (dispath) => ({
  getProspectsList: () => { dispath(getProspectsList()); },
  deleteProspect: (prospect) => { dispath(deleteProspect(prospect)); },

});

const mapStateToProps = (state) => ({
  prospects: makeSelectProspectsList()(state),
  agences: makeSelectAgencesList()(state)
});

export default withRouter(connect(mapStateToProps, mapDispatchToProps)(ProspectsListContainer));
