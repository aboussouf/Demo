import React from 'react';

class MapMarker extends React.Component
{
    constructor(props){
    super(props)

    }


    render(){ 
        return (
            <div id="content" >
            <p>
            <img src="http://www.louis-serge-real-del-sarte.com/var/f/l8/nq/l8nqkBfAJpig6oW4M3YzmEnHqw9UKGsTPVevZr20hRaO8_juc1.jpg" alt="" />
            </p>
            <p>
            Votre agence: {this.props.agence.name}
            Adresse: {this.props.agence.adresse}
            Telephone: : {this.props.agence.tele}
            </p>
            <p><button onClick ={this.props.action}>Sélectionner</button></p>
            </div>
        );
    }
}

export default MapMarker ;