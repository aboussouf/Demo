import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import {Map, InfoWindow, Marker, GoogleApiWrapper} from 'google-maps-react';
/*import { Map, InfoWindow, Marker, GoogleApiWrapper} from 'react-google-maps';
import MarkerClusterer from 'react-google-maps/lib/components/addons/MarkerClusterer';*/

import RaisedButton from 'material-ui/RaisedButton';
import ActionAndroid from 'material-ui/svg-icons/action/android';
import FontIcon from 'material-ui/FontIcon';
import SvgIcon from 'material-ui/SvgIcon';

import configureStore from '../../../configureStore';
import MapMarker from './MapMarker';
import { Provider } from 'react-redux';

const store = configureStore();
const styles = {
  icon: {
    background: 'url(http://www.broken-links.com/tests/images/faces.svg#devil-view)',
  }
}

 class MapView extends React.Component {
  constructor (props) {
    super(props)

    const {lat, lng} = this.props.initialCenter;
    this.state = {
      currentLocation: {
        lat: lat,
        lng: lng
      },  
      centerAroundCurrentLocation : false,
      fetchingPosition: false,
      position: undefined,
      error: undefined,
      loaded: false,
      selectedAgence : undefined,
    }

    // This binding is necessary to make `this` work in the callback
    this.functionCurrentLocation = this.functionCurrentLocation.bind(this);
    this.currentPosition = this.currentPosition.bind(this);
  }

  getCurrentPosition = () => {
    const {
      currentLocation,
      enableHighAccuracy,
      timeout,
      maximumAge,
      onSuccess,
      onError
    } = this.props
    console.log("getcurrentposition",this.props.city)
    this.setState({ currentLocation:{lat:this.props.city.latitude,  lng:this.props.city.longitude},fetchingPosition: true })

    return window.navigator.geolocation.getCurrentPosition(
      position => {
        if (this.willUnmount) return

        this.setState({ position,  currentLocation:{lat:this.props.city.latitude,  lng:this.props.city.longitude} }, () =>
          onSuccess(position)
        )
      },
      err => {
        if (this.willUnmount) return

        this.setState({ err,  currentLocation:{lat:this.props.city.latitude,  lng:this.props.city.longitude} }, () => onError(err))
      },
      { currentLocation,enableHighAccuracy, timeout, maximumAge }
    )
  }
  
  currentPosition(){
   this.map.panTo(currentLocation);
  }
  
  /*onPlacesChanged = () => {
    if (this.props.onPlacesChanged) {
      this.props.onPlacesChanged(this.searchBox.getPlaces());
    }
  }*/

  componentDidMount = () => {
    // Ali 20180402
    /*console.log("20180402");
    const refs = this.refs;
    this.scriptCache.google.onLoad((err, tag) => {
      const maps = window.google.maps;
      const props = Object.assign({}, this.props, {
        loaded: this.state.loaded
      });
      const mapRef = refs.map;
      console.log("Fin 20180402");*/
    // Fin 20180402
    //this.map.panTo(centerAroundCurrentLocation);
   /*if (this.props.centerAroundCurrentLocation) {
          if (navigator && navigator.geolocation) {
              navigator.geolocation.getCurrentPosition((pos) => {
                  const coords = pos.coords;
                  this.setState({
                      currentLocation: {
                          lat: this.props.city.latitude,
                          lng: this.props.city.longitude
                      }
                  })
              })
          }
      }*/
      this.loadMap();
    }

   componentWillMount () {

      if (typeof window !== 'object') {
        return
      }
  
      if (!('mapcontainer' in window.navigator)) {
        return
      }
  
      if (this.props.lazy) {
        return
      }
  
      this.getCurrentPosition()
    }
  
    componentWillUnmount () {
      this.willUnmount = true
    }

  // ======================
  // ADD LOCATIONS TO STATE
  // ======================
  state = {
    locations: [
      { name: 'Test 1', location: {lat:33.5926823,lng:-7.637372699999999}},
      { name: 'Test 2', location: {lat:33.5881494,lng:-7.6398432000000005}},
      { name: 'Test 3', location: {lat:33.5898884,lng:-7.638024499999999}},
      { name: 'Test 4', location: {lat:33.592659999999995,lng:-7.6429329}},
      { name: 'Test 5', location: {lat:33.58781,lng:-7.6431313}},
      { name: 'Test 6', location: {lat:33.5873458,lng:-7.6322429}},
      { name: 'Test 7', location: {lat:33.5846636,lng:-7.632670699999999}},
      { name: 'Test 8', location: {lat:33.58229,lng:-7.6403099999999995}},
      { name: 'Test 9', location: {lat:33.5901172,lng:-7.626318299999999}},
      { name: 'Test 10', location: {lat:33.581188499999996,lng:-7.623835499999999}},
      { name: 'Test 11', location: {lat:33.5787232,lng:-7.6456685}},
      { name: 'Test 12', location: {lat:33.60053,lng:-7.637930000000001}},
      { name: 'Test 13', location: {lat:33.5881033,lng:-7.6172925000000005}},
      { name: 'Test 14', location: {lat:33.581749699999996,lng:-7.6346015}},
      { name: 'Test 15', location: {lat:33.5697025,lng:-7.6517553000000005}},
      { name: 'Test 16', location: {lat:33.5796142,lng:-7.6174642}},
      { name: 'Test 17', location: {lat:33.5983543,lng:-7.6448599999999995}},
      { name: 'Test 18', location: {lat:33.56854,lng:-7.62629}}, 
      { name: 'Test 19', location: {lat:33.59478,lng:-7.61448}},
      { name: 'Test 20', location: {lat:33.5715809,lng:-7.6590143}}
    ],
  }

  componentDidUpdate(prevProps, prevState) {
    console.log('componentDidUpdate',this.state.currentLocation);
    window.initMap = this.initMap;
    if (prevProps.google !== this.props.google) {
      console.log("loadmap.agences1", this.props.agences);
      this.loadMap();
    }
    if (prevProps.city !== this.props.city) {
      console.log("loadmap.agences2", this.state.currentLocation);
      this.setState({currentLocation:{lat : this.props.city.latitude, lng: this.props.city.longitude}, agences: this.props.agences});  
      this.recenterMap();
    }
    if (prevState.functionCurrentLocation !== this.state.functionCurrentLocation) {
      console.log("loadmap.agences3", this.state.currentLocation);
      this.recenterMap();
    }
  }

   selectAgence(agence) {
    this.setState({selectedAgence : agence});
    this.props.setAgenceSelectionnee (agence);
    }

  recenterMap() {
    const map = this.map;
    const curr = this.state.currentLocation;

    const google = this.props.google;
    const maps = google.maps;

    if (map) {
        let center = new maps.LatLng(curr.lat, curr.lng)
        // 20180402
        map.setCenter(center);
        map.panTo(center)
    }
  }

  loadMap() {
    if (this.props && this.props.google) { // checks to make sure that props have been passed
      console.log("loadmap.agences", this.props.agences);
      const {google} = this.props; // sets props equal to google
      const maps = google.maps; // sets maps to google maps props

      const mapRef = this.refs.map; // looks for HTML div ref 'map'. Returned in render below.
      const node = ReactDOM.findDOMNode(mapRef); // finds the 'map' div in the React DOM, names it node
      // Ali activating current localization
      let {initialCenter, zoom} = this.props;
      const {lat, lng} = initialCenter;
      //const {lat, lng} = this.state.currentLocation;
      const center = new maps.LatLng(this.props.city.latitude, this.props.city.longitude);
      // Fin Ali 

      const mapConfig = Object.assign({}, {
        center: center,
        zoom: zoom, // sets zoom. Lower numbers are zoomed further out.
        mapTypeId: 'roadmap' // optional main map layer. Terrain, satellite, hybrid or roadmap--if unspecified, defaults to roadmap.
      })

      this.map = new maps.Map(node, mapConfig); // creates a new Google map on the specified node (ref='map') with the specified configuration set above.

      var infowindow = new google.maps.InfoWindow();
      
      var markers = []; 
      var labels = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      var labelIndex = 0;

                

  // ==================
  // ADD MARKERS TO MAP
  // ==================

    

    this.props.agences.forEach(agence =>{
      var image = 'http://www.louis-serge-real-del-sarte.com/var/f/l8/nq/l8nqkBfAJpig6oW4M3YzmEnHqw9UKGsTPVevZr20hRaO8_juc1.jpg';
        
      const marker = new google.maps.Marker({ // creates a new Google maps Marker object.
        position: {lat:  parseFloat(agence.latitude), lng: parseFloat(agence.longitude)}, // sets position of marker to specified location
        map: this.map, // sets markers to appear on the map we just created on line 35
        label: "C",
        animation: google.maps.Animation.DROP,
        icon: image,
        title: agence.name // the title of the marker is set to the name of the location
      });

      

      var contentString = document.createElement('div')
      ReactDOM.render( <Provider store ={store}>
          <MapMarker agence ={agence} action = {() =>{this.selectAgence(agence)}} />
        </Provider>, contentString)
                       
        var infowindow = new google.maps.InfoWindow({
          content: contentString,
          maxWidth: 200,
        });
        
        //google.maps.event.addListener(infowindow, 'closeclick', infowindow.onClose.bind(infowindow));

        marker.addListener('mouseover', function() {
          infowindow.close();
          infowindow.open(this.map, marker);
        });

        marker.addListener('mouseout', function() {
          //infowindow.close();
        });

        marker.addListener('click', function() {
          infowindow.open(this.map, marker);
          this.map.setCenter(marker.getPosition());
          this.map.setZoom(15);
          
        });

        marker.addListener('mousedown', function() {
          //infowindow.open(this.map, marker);
        });

        marker.addListener('mouseup', function() {
          infowindow.close();
        });
  

        /*google.maps.event.addListener(marker, 'mousedown', function() {
          infowindow.open(this.map, marker);
          });
        google.maps.event.addListener(marker, 'mouseup', function() {
          infowindow.close();
          });*/

        /*marker.child.addListener('close', function() {
          console.log("map.infowindow.close", infowindow);
          //infowindow.close();
          
         // this.map.refs.marker.close();
        });*/

        marker.addListener('closeclick',function(){
          console.log("map.infowindow.closeclick", marker);
          //currentMark.setMap(null); 
       });

        /*google.maps.event.addListener(infowindow, 'click2', function() {
          console.log("map.infowindow.click2", infowindow);
          infoWindow.onClose().bind(this);
          //currentMark.setMap(null);
        });*/
        markers.push(marker);
        // Add a marker clusterer to manage the markers.
        /*var markerCluster = new MarkerClusterer(this.map, markers,
          {imagePath: 'http://www.louis-serge-real-del-sarte.com/var/f/l8/nq/l8nqkBfAJpig6oW4M3YzmEnHqw9UKGsTPVevZr20hRaO8_juc1.jpg'});*/

        google.maps.event.trigger(infowindow, 'closeclick');

        
    });
  
      
      //  Centrer la map au milieu de la ville séléctionnée
      //this.props.functionCurrentLocation;

    }

  }


  // activating current localization
  functionCurrentLocation(){
     this.setState({ centerAroundCurrentLocation:true });

     if (navigator && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((pos) => {
          const coords = pos.coords;
          this.setState({
              currentLocation: {
                  lat: coords.latitude,
                  lng: coords.longitude
              }
          })
      })
    }       
  }
  // Fin

  render() {
    const style = { // MUST specify dimensions of the Google map or it will not work. Also works best when style is specified inside the render function and created as an object
      width: '45vw', // 90vw basically means take up 90% of the width screen. px also works.
      height: '35vh' // 75vh similarly will take up roughly 75% of the height of the screen. px also works.
    }
  
    
    return ( 
    // in our return function you must return a div with ref='map' and style.
    <div>
      <div>
        <RaisedButton label="Trouver ma position" 
                      onClick={this.functionCurrentLocation}  
                      secondary={true} 
           
                      />        
      </div>
      
      <div ref="map" style={style}  >
        loading map...        
      </div>
      
      

        {this.state.selectedAgence != undefined ?
        <div >
               <p>Nom Agence:  {this.state.selectedAgence.name}  </p> 
               <p>Adresse :  {this.state.selectedAgence.adresse}</p>  
               <p>Tel :  {this.state.selectedAgence.tele}</p> 
                   
        </div>
        :
        null 
        }
            
    </div>
    
    )
    
  }
}


MapView.propTypes = {
  agences: PropTypes.array.isRequired,
  // activating current localization
  google: React.PropTypes.object,
  zoom: React.PropTypes.number,
  initialCenter: React.PropTypes.object,
  centerAroundCurrentLocation: PropTypes.bool,
  placeholder: React.PropTypes.string,
  onPlacesChanged: React.PropTypes.func,
  setAgenceSelectionnee: React.PropTypes.func.isRequired,
  // Fin 

   // https://developer.mozilla.org/en-US/docs/Web/API/PositionOptions
   enableHighAccuracy: PropTypes.bool,
   timeout: PropTypes.number,
   maximumAge: PropTypes.number,
   // https://developer.mozilla.org/en-US/docs/Web/API/Geolocation/getCurrentPosition
   onSuccess: PropTypes.func,
   onError: PropTypes.func,
   // Do not call getCurrentPosition on mount
   lazy: PropTypes.bool
};
MapView.defaultProps = {
 
  zoom: 11,
  // Rabat, by default
  initialCenter: {
    lat: 34.0132500,
     lng: -6.8325500
  },
   // activating current localization
  centerAroundCurrentLocation: false,
  // Fin
  enableHighAccuracy: false,
  timeout: Infinity,
  maximumAge: 0,
  onSuccess: pos => {},
  // eslint-disable-next-line handle-callback-err
  onError: err => {},
  lazy: false
}


export default  GoogleApiWrapper ({
  apiKey: 'AIzaSyBlJW6kcMa_2qn5HRv7e--U6rCwHnx9joA'
}) (MapView);

