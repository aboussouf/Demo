import React, { Component } from 'react';
import PropTypes from 'prop-types';
import IdentityComponent from 'components/IdentityComponent';
import ProspectInfo from 'components/ProspectInfo'
import ChoseAgency from 'components/ChoseAgency'
import ProductChoiceComponent from 'components/ProductChoiceComponent';
import RDVContainer from 'containers/RDVContainer';
import { connect } from 'react-redux';
import { Step,Stepper,StepLabel} from 'material-ui/Stepper';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Paper from 'material-ui/Paper';
import { makeSelectSelectedCity } from 'store/selectors/Referentiel';
import { styles } from './styles';
import {setProspect,saveProspect} from '../../store/actions/prospect'
import {getCities} from '../../store/actions/Geolocs'
import ChoseRdv from '../../components/ChoseRdv';
import Recap from '../../components/Recap';
import {makeSelectProspect } from '../../store/selectors/Prospect';
import {makeSelectStep} from '../../store/selectors/Steps';
import { goToStep } from '../../store/actions/Steps';

export class SignUpContainer extends Component {
  
  constructor(props) {
    super(props)
  }
  
  state = {
    identityFormValues: {
      cmdp: true,
      sexe: null,
      lastName: '',
      firstName: '',
      dateOfBirth: '',
      email: '',
      tele: '',
      part:true,
      prof:false,
    },
    selectedProductId: null,
    stepIndex: 0,
    rdvInformations: {
      selectedCity: null,
      selectedAgence: null,
      selectedDate: null,
      selectedTime: '',
    },
    nextProps: {
      selectedCity: null,
      selectedAgence: null,
      selectedDate: null,
      selectedTime: '',
    },
  }
  componentWillMount(){}

  componentWillReceiveProps = (nextProps) => {
    if (nextProps && nextProps.selectedCity) {
      this.rdvInfosChange('selectedCity', nextProps.selectedCity);
    }
  }
  onEventValFieldChange = (event, value) => {
    this.setState({
      ...this.state,
      identityFormValues: {
        ...this.state.identityFormValues,
        [event.target.name]: value,
      },
    });
  }

  /**
   * dispatch action to put info prospect to store
   * @param {*} prospect 
   */
  validStepInfoProspect (prospect)  {
   
    console.log('validStepInfoProspect prospect',prospect); 
    
    if (this.props.step.stepIndex==3){
      
      this.props.validStepOneStore({
        idProspect:0,
        firstName: prospect.firstName,
        lastName: prospect.lastName,
        tele: prospect.tele,
        email: prospect.email,
        typeProspect: prospect.particularite,
        boisson: this.props.prospect.boisson,
        dateRdv: this.props.prospect.dateRdv,
        heureRdv: this.props.prospect.heureRdv,
        cmdp: this.props.prospect.cmdp,
        sexe: this.props.prospect.sexe,
        agence: this.props.prospect.agence,
      })
      this.setState({ stepIndex:this.props.step.stepIndex });
    }
    else {
      this.props.validStepOneStore({
        firstName: prospect.firstName,
        lastName: prospect.lastName,
        tele: prospect.tele,
        email: prospect.email,
        particularite: prospect.particularite,
        agence: this.props.prospect.agence
      })
      this.handleNextStep(); 
    }

  }
  /**
   * dispatch action to put date && hour rdv to store
   * @param {*} prospect 
   */
  valideStepChoseRdv(rdvInfo){
      this.props.validStepOneStore({
        idProspect:0,
        firstName: this.props.prospect.firstName,
        lastName: this.props.prospect.lastName,
        tele: this.props.prospect.tele,
        email: this.props.prospect.email,
        typeProspect: this.props.prospect.particularite,
        boisson: "CAFE",
        dateRdv: rdvInfo.date,
        heureRdv: rdvInfo.hour,
        cmdp: 1,
        sexe: 1,
        agence: this.props.prospect.agence,
      })

      this.handleNextStep();
  }
  valideStepRDVContainer(){
    this.handleNextStep();
  }
  /**
   * dispatch action to put date && hour rdv to store
   * @param {*} prospect 
   */
  valideStepRecap (prospect){
      this.props.persistProspect(prospect);
  }
  /** 
   * return to step 1
  */
  goToStep(stepIndex){
    this.props.goToAction({ stepIndex:3});
    this.setState({ stepIndex:stepIndex });
  }

  getStepContent = (stepIndex) => {
    switch (stepIndex) {
      case 0: return (<ProspectInfo 
                          onValidateStep={this.validStepInfoProspect.bind(this)}
                          prospect= {this.props.prospect}
                          step={this.props.step}
                    />);
      case 1: return (<RDVContainer
                      cities={this.props.cities}
                      agences={this.props.agences}
                      rdvInfosChange={this.rdvInfosChange}
                      rdvInfos={this.state.rdvInformations}
                      getCityAgences={this.props.getCityAgences}
                      onPrevStep={this.handlePrevStep.bind(this)}
                      onValidateStep={this.valideStepRDVContainer.bind(this)}
              
              />);
                    
        case 2: return (<ChoseRdv 
                            onValidateStep={this.valideStepChoseRdv.bind(this)}
                            onPrevStep={this.handlePrevStep.bind(this)}
                            prospect={this.props.prospect}
                />);
        case 3: return (<Recap 
                            onValidateStep={this.valideStepRecap.bind(this)}
                            onPrevStep={this.handlePrevStep.bind(this)}
                            prospect={this.props.prospect}
                            onChangeInfo={this.goToStep.bind(this)}
                           
                /> );
                
      default: return "";
    }
  }
  handleNextStep = () => {
    const { stepIndex } = this.state;
    if (stepIndex < this.lastStepIndex) {
      this.setState({ stepIndex: stepIndex + 1 });
    }
  }
  handlePrevStep = () => {
    const { stepIndex } = this.state;

    if (stepIndex > 0) {
      this.setState({ stepIndex: stepIndex - 1 });
    }
  }
  handleSubmit = () => {
    this.props.onSubmit(this.state.identityFormValues);
  }
  productSelectionChange = (event, index, value) => {
    this.setState({
      ...this.state,
      selectedProductId: value,
    });
  }
  identityFieldChange = (event) => {
    this.onEventValFieldChange(event, event.target.value);
  }

 


  identityParticulariterClick = (event) => {
  
   this.state.identityFormValues.part=!this.state.identityFormValues.part;
  }
  rdvInfosChange = (field, value) => {
    this.setState({
      ...this.state,
      rdvInformations: {
        ...this.state.rdvInformations,
        [field]: value,
      },
    });
  }
  lastStepIndex = 3;

  render() {
    const { stepIndex } = this.state;
    return (
      <Paper style={styles.pageContainerStyle} zDepth={5} rounded={false}>
        <Stepper activeStep={stepIndex}>
          <Step>
            <StepLabel>{'Informations d\'identité'}</StepLabel>
          </Step>
          <Step>
            <StepLabel>{'Choix du produit'}</StepLabel>
          </Step>
          <Step>
            <StepLabel>{'Rendez-vous'}</StepLabel>
          </Step>
        </Stepper>
        {this.getStepContent(stepIndex)}
        
      </Paper>
    );
  }
}

SignUpContainer.propTypes = {
  products: PropTypes.array.isRequired,
  onSubmit: PropTypes.func.isRequired,
  getCityAgences: PropTypes.func.isRequired,
  cities: PropTypes.array.isRequired,
  countrys: PropTypes.array.isRequired,
};

const mapStateToProps = (state) => ({
  selectedCity: makeSelectSelectedCity()(state),
  selectedAgences: makeSelectSelectedCity()(state),
  prospect: makeSelectProspect()(state),
  step: makeSelectStep()(state)
});

const mapDispatchToProps = (dispath) => ({
  validStepOneStore: (prospect) => { dispath(setProspect(prospect)); },
  persistProspect: (prospect) => { dispath(saveProspect(prospect)); },
  goToAction: (location) => { dispath(goToStep(location)); },
});



export default connect(mapStateToProps, mapDispatchToProps)(SignUpContainer);
