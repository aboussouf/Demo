export const styles = {
  pageContainerStyle: {
    width: '80%',
    margin: '0 auto',
    marginTop: '50px',
    padding: '50px',
  },
  stepperButtonsContainerStyle: {
    marginTop: '50px',
    textAlign: 'center',
  },
};
