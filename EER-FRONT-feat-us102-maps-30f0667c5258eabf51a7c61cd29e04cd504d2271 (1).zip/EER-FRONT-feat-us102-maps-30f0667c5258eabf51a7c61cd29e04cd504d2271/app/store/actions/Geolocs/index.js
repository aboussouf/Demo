export const SET_AGENCE_SELECTIONNEE = 'SET_AGENCE_SELECTIONNEE';
export const GET_AGENCE_SELECTIONNEE = 'GET_AGENCE_SELECTIONNEE';

export const SET_AGENCES_LIST = 'SET_AGENCES_LIST';
export const GET_AGENCES_LIST = 'GET_AGENCES_LIST';

export const SET_CITIES_LIST = 'SET_CITIES_LIST';
export const GET_CITIES_LIST = 'GET_CITIES_LIST';

export const SET_COUNTRYS_LIST = 'SET_COUNTRYS_LIST';
export const GET_COUNTRYS_LIST = 'GET_COUNTRYS_LIST';

export const SET_AGENCYS_BY_COUNTRY_LIST = 'SET_AGENCY_BY_COUNTRY_LIST';
export const GET_AGENCYS_BY_COUNTRY_LIST = 'GET_AGENCY_BY_COUNTRY_LIST';

export const SET_AGENCYS_BY_CITIE_LIST = 'SET_AGENCYS_BY_CITIE_LIST';
export const GET_AGENCYS_BY_CITIE_LIST = 'GET_AGENCYS_BY_CITIE_LIST';

// agency selection actions
const setAgenceSelectionnee = (agence) => ({  type: SET_AGENCE_SELECTIONNEE, payload: agence});
const getAgenceSelectionnee = () => ({ type: GET_AGENCE_SELECTIONNEE});

// agency actions
const setAgences = (agences) => ({  type: SET_AGENCES_LIST, payload: agences});
const getAgences = () => ({ type: GET_AGENCES_LIST});
// cities actions
const setCities = (cities) => ({  type: SET_CITIES_LIST, payload: cities});
const getCities = () => ({ type: GET_CITIES_LIST});
// country actions
const setCountrys = (countrys) => ({  type: SET_COUNTRYS_LIST, payload: countrys});
const getCountrys = (cityId)  => ({ type: GET_COUNTRYS_LIST, payload: cityId});
// agency by country actions
const setAgencysByCountry = (agencys) => ({  type: SET_AGENCYS_BY_COUNTRY_LIST, payload: agencys});
const getAgencysByCountry = (countryId)  => ({ type: GET_AGENCYS_BY_COUNTRY_LIST, payload: countryId});
// agency by country actions
const setAgencysByCitie = (cities) => ({  type: SET_AGENCYS_BY_CITIE_LIST, payload: cities});
const getAgencysByCitie = (citieID)  => ({ type: GET_AGENCYS_BY_CITIE_LIST, payload: citieID});
// export all geolocs actions
export {
  getAgenceSelectionnee,
  setAgenceSelectionnee,
  getAgences,
  setAgences,
  setCities,
  getCities,
  setCountrys,
  getCountrys,
  setAgencysByCountry,
  getAgencysByCountry,
  setAgencysByCitie,
  getAgencysByCitie
};
