export const GET_PUBLIC_IP = 'GET_PUBLIC_IP';

const getPublicIPAdress = () => ({ type: GET_PUBLIC_IP });
export default getPublicIPAdress;
