export const SET_PUBLIC_IP = 'SET_PUBLIC_IP';

const setPublicIPAdress = (ip) => ({ type: SET_PUBLIC_IP, payload: ip });
export default setPublicIPAdress;
