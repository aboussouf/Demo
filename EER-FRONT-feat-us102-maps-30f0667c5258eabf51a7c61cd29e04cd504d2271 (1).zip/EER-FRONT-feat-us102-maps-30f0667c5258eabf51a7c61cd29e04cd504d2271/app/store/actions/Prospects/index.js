export const GET_PROSPECTS_LIST = 'GET_PROSPECTS_LIST';
export const SET_PROSPECTS_LIST = 'SET_PROSPECTS_LIST';

export const DELETE_PROSPECT = 'DELETE_PROSPECT';

const getProspectsList = () => ({
  type: GET_PROSPECTS_LIST,
});
const setProspectsList = (prospects) => ({
  type: SET_PROSPECTS_LIST,
  payload: prospects,
});
const deleteProspect = (prospect) => ({
  type: DELETE_PROSPECT,
  payload: prospect,
});

export {
    getProspectsList,
    setProspectsList,
    deleteProspect,
};
