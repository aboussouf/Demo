export const GET_PRODUCTS_LIST = 'GET_PRODUCTS_LIST';
export const SET_PRODUCTS_LIST = 'SET_PRODUCTS_LIST';

const getProductsList = () => ({ type: GET_PRODUCTS_LIST });
const setProductsList = (products) => ({ type: SET_PRODUCTS_LIST, payload: products });

export const GET_CITIES_LIST = 'GET_CITIES_LIST';
export const SET_CITIES_LIST = 'SET_CITIES_LIST';

const getCitiesList = () => ({ type: GET_CITIES_LIST });
const setCitiesList = (cities) => ({ type: SET_CITIES_LIST, payload: cities });

export const GET_CITY_AGENCES = 'GET_CITY_AGENCES';
export const SET_SELECTED_AGENCES = 'SET_SELECTED_AGENCES';

const getCityAgences = (cityId) => ({ type: GET_CITY_AGENCES, payload: cityId });
const setSelectedCity = (cityId, agences) => ({ type: SET_SELECTED_AGENCES, payload: {cityId, agences} });

export {
    getProductsList,
    setProductsList,
    getCitiesList,
    setCitiesList,
    getCityAgences,
    setSelectedCity,
};
