
export const GO_TO_STEP = 'GO_TO_STEP';
// route actions
const goToStep = (stepIndex) => ({  type: GO_TO_STEP, payload: stepIndex});
// export all routes actions
export {
  goToStep,
};
