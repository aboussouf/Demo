import { fromJS } from 'immutable';
import { SET_AGENCES_LIST, 
  SET_CITIES_LIST,
  SET_COUNTRYS_LIST,
  SET_AGENCYS_BY_COUNTRY_LIST,
  SET_AGENCYS_BY_CITIE_LIST } from 'store/actions/Geolocs';

/**
 * init state with empty list
 */

const initState = {
  agences: fromJS([{
           /* idAgence: 1,
            name: "name 1",
            adresse: "81, Rue Al Hoceima, Fès",
            tele: "05224-24243",
            longitude: -7.637372699999999,
            latitude: 33.5926823, */
          }]),

  cities: fromJS([
    {
        id: 7,
        name: 'Casa',
        agences: [{
          id: 1,
          name: 'Nouacer',
        }, {
          id: 2,
          name: 'Ghandi',
        }, {
          id: 20,
          name: 'Sidi maarouf',
        }],
  },
   {
    id: 46,
    name: 'Taza',
    agences: [{
      id: 3,
      name: 'Principale',
    }, {
      id: 4,
      name: 'Haut',
    }],
  }]),

  countrys: fromJS([
    {
        id: 1,
        libelle: 'maarif',
        ville: 1,
        
  }]),

};

function agencesReducer(state = initState, action) {
  switch (action.type) {
    case SET_AGENCES_LIST: 
          return ({
            ...state,
              agences: fromJS(action.payload),
            });
    case SET_AGENCYS_BY_COUNTRY_LIST:
            return ({
              ...state,
              agences: fromJS(action.payload),
            });
    case SET_AGENCYS_BY_CITIE_LIST:
            return ({
              ...state,
              agences: fromJS(action.payload),
            });       
    case SET_CITIES_LIST:
          return ({
            ...state,
            cities: fromJS(action.payload),
          });
    case SET_COUNTRYS_LIST:
          return ({
            ...state,
            countrys: fromJS(action.payload),
          });
    default:
      return state;
  }
}

export default agencesReducer;

