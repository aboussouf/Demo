import { fromJS } from 'immutable';

const headerInitialState = fromJS({
  headerTitle: 'Digital Factory SGMA',
});

function headerReducer(state = headerInitialState) {
  return state;
}

export default headerReducer;
