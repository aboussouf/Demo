import { fromJS } from 'immutable';
import { SET_PUBLIC_IP } from 'store/actions/IpViewer';

const IpInitialState = fromJS({
  ipAdress: null,
});

function ipReducer(state = IpInitialState, action) {
  switch (action.type) {
    case SET_PUBLIC_IP:
      return { ipAdress: action.payload };
    default:
      return state;
  }
}

export default ipReducer;
