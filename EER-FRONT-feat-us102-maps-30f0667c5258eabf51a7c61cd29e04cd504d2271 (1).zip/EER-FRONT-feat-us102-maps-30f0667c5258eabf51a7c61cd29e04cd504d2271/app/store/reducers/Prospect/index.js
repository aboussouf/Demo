import { fromJS } from 'immutable';
import { SET_PROSPECT } from 'store/actions/Prospect';
import { SET_AGENCE_SELECTIONNEE } from '../../actions/Geolocs';

const prospectInitState = fromJS(
 /* {
    id: 1,
    firstName: 'Issam',
    lastName: 'Nacim',
    tele: '0600699129',
    email: 'nacim.issam@gmail.com',
    sexe: false,
    cmdp: false,
    agence:{
      idAgence:1,
      name:"CASA MOULAY YOUSSEF",
      adresse:"38, boulvard moulay YOUSSEF",
    }
} */
{
  idProspect:0,
  firstName:'issam',
  cmdp: 1,
  sexe: 1,
  lastName:'nacim',
  tele:'0000000000',
  email:'nacim.issam@gmail.com',
  typeProspect:'PARTICULIER',
  boisson: 'CAFE',
  dateRdv:'2018-02-08',
  heureRdv:'20H44',
  agence:
    {
    idAgence:'1',
    name:'CASA MOULAY YOUSSEF',
    adresse:'38, boulvard moulay YOUSSEF'
      
    }
  }

);

function prospectReducer(state = prospectInitState, action) {
  switch (action.type) {
    case SET_PROSPECT:
    return  fromJS(action.payload) ;
    case SET_AGENCE_SELECTIONNEE:
    return state.set('agence', fromJS(action.payload));
      
    default:
      return state;
  }
}

export default prospectReducer;
