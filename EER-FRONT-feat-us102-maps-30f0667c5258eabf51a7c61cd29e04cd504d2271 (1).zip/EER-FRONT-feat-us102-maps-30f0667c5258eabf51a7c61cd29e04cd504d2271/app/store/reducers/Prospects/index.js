import { fromJS } from 'immutable';
import { SET_PROSPECTS_LIST } from 'store/actions/Prospects';

const prospectsInitState = fromJS({
  list: fromJS([
        // {
        //   id: 1,
        //   firstName: 'Issam',
        //   lastName: 'Nacim',
        //   tele: '0600699129',
        //   email: 'nacim.issam@gmail.com',
        //   sexe: false,
        //   cmdp: false,
        // },
        // {
        //   id: 2,
        //   firstName: 'Issam2',
        //   lastName: 'Nacim2',
        //   tele: '0600699129',
        //   email: 'nacim.issam@gmail.com',
        //   sexe: false,
        //   cmdp: false,
        // },
  ]),
});

function prospectsReducer(state = prospectsInitState, action) {
  switch (action.type) {
    case SET_PROSPECTS_LIST:
      return { list: fromJS(action.payload) };
    default:
      return state;
  }
}

export default prospectsReducer;
