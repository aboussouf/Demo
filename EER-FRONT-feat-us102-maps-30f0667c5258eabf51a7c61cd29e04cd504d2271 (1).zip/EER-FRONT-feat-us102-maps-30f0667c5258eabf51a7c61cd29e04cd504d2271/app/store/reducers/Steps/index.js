import { fromJS } from 'immutable';
import { GO_TO_STEP } from '../../actions/Steps';



/**
 * init state with empty list
 */

const initState = fromJS(
    {
    stepIndex:0,
    } 
 );

function stepReducer(state = initState, action) {
  switch (action.type) {
    case GO_TO_STEP: 
          return fromJS(action.payload);
    default:
      return state;
  }
}

export default stepReducer;

