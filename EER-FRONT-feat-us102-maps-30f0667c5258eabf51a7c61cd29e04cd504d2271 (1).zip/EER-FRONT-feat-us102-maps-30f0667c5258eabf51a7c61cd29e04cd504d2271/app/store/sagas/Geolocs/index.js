import { takeLatest, put } from 'redux-saga/effects';
import {
  setAgences,
  setCities,
  setCountrys,
  setAgencysByCountry,
  GET_AGENCES_LIST,
  GET_CITIES_LIST,
  GET_COUNTRYS_LIST,
  GET_AGENCYS_BY_COUNTRY_LIST } from 'store/actions/Geolocs';
import { setAgencysByCitie, GET_AGENCYS_BY_CITIE_LIST } from '../../actions/Geolocs';

// function* pour récupèrer la liste des agences Geoloc pour une ville donnée
function* getAgencesWorker() {
    try {
            const list = yield fetch('http://10.85.12.107:8762/api/geolocalisation/agence')
                                .then((res) => res.json())
                                .catch((err) => console.log(err));
                                yield put(setAgences(list));
        } 
    catch (e) {
        console.log(e);
    }
  }

  function* getAgencesWatcher() {
    yield takeLatest(GET_AGENCES_LIST, getAgencesWorker);
  }

// Saga to get list of cities 
  function* getCitiesWorker() {
    try {
            const list = yield fetch('http://10.85.12.107:8762/api/geolocalisation/ville')
                               .then((res) => res.json())
                               .catch((err) => console.log(err));
                                yield put(setCities(list));
        } 
    catch (e) {
        console.log(e);
    }
  }

  function* getCitiesGeolocWatcher() {
    yield takeLatest(GET_CITIES_LIST, getCitiesWorker);
  }

  // Saga to get list of countrys 
  function* getCountrysWorker(action) {
    try {
            const list = yield fetch(`http://10.85.12.107:8762/api/geolocalisation/ville/${action.payload}/quartiers`)
                               .then((res) => res.json())
                               .catch((err) => console.log(err));
                                yield put(setCountrys(list));
        } 
    catch (e) {
        console.log(e);
    }
  }

  function* getCountrysGeolocWatcher() {
    yield takeLatest(GET_COUNTRYS_LIST, getCountrysWorker);
  }

   // Saga to get list of agency by country 
   function* getAgencyByCountryWorker(action) {
    try {
            const list = yield fetch(`http://10.85.12.107:8762/api/geolocalisation/quartier/${action.payload}/agences`)
                               .then((res) => res.json())
                               .catch((err) => console.log(err));
                                yield put(setAgencysByCountry(list));
        } 
    catch (e) {
        console.log(e);
    }
  }

  function* getAgencyByCountryGeolocWatcher() {
    yield takeLatest(GET_AGENCYS_BY_COUNTRY_LIST, getAgencyByCountryWorker);
  }

     // Saga to get list of agency by citie 
     function* getAgencyByCitieWorker(action) {
      try {
              const list = yield fetch(`http://10.85.12.107:8762/api/geolocalisation/ville/${action.payload}/agences`)
                                 .then((res) => res.json())
                                 .catch((err) => console.log(err));
                                  yield put(setAgencysByCitie(list));
          } 
      catch (e) {
          console.log(e);
      }
    }
  
    function* getAgencyByCitieGeolocWatcher() {
      yield takeLatest(GET_AGENCYS_BY_CITIE_LIST, getAgencyByCitieWorker);
    }
// export all sagas functions
  export {
    getAgencesWatcher,
    getCitiesGeolocWatcher,
    getCountrysGeolocWatcher,
    getAgencyByCountryGeolocWatcher,
    getAgencyByCitieGeolocWatcher
  };