import { takeLatest, put } from 'redux-saga/effects';
import { GET_PUBLIC_IP } from 'store/actions/Header';
import setPublicIPAdress from 'store/actions/IpViewer';

function* getIpWatcher() {
  yield takeLatest(GET_PUBLIC_IP, getPublicIPAdress);
}

function* getPublicIPAdress() {
  try {
    const ip = yield fetch('https://jsonip.com/')
            .then((res) => res.json())
            .then((ipJson) => ipJson.ip)
            .catch((err) => console.log(err));
    yield put(setPublicIPAdress(ip));
  } catch (e) {
    console.log(e);
  }
}

export default getIpWatcher;
