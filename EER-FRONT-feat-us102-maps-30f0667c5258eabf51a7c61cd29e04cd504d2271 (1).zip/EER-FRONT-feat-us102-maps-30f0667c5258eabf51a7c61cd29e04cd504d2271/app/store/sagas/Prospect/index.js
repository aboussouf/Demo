import { takeLatest, put } from 'redux-saga/effects';
import { SAVE_PROSPECT } from 'store/actions/Prospect';

/* function* saveProspectWorker() {
  try {
    const list = yield fetch('http://10.85.12.107:8762/api/prospect/prospect')
            .then((res) => res.json())
            .catch((err) => console.log(err));
    yield put(setProspectsList(list));
  } catch (e) {
    console.log(e);
  }
} */

function* saveProspectWorker(action) {
  console.log('saveProspectWorker :',JSON.stringify({ ...action.payload }))
  try {
    yield fetch('http://10.85.12.107:8762/api/prospect/prospect',
      {
        method: 'POST',
        body: JSON.stringify({ ...action.payload }),
        headers: { 'Content-Type': 'application/json' },
      })
      .then((res) => res.json())
      .catch((err) => console.log(err));
    yield put(push('/'));
  } catch (e) {
    console.log(e);
  }
}

function* saveProspectsWatcher() {
  yield takeLatest(SAVE_PROSPECT, saveProspectWorker);
}


export {
  saveProspectsWatcher,
};
