import { takeLatest, put } from 'redux-saga/effects';
import { CLIENT_REGISTRATION_SUBMIT } from 'store/actions/SignUp';
import { push } from 'react-router-redux';

function* registerCientWorker(action) {
  console.log('saga ', action);
  try {
    yield fetch('http://10.85.12.107:8765/api/prospect/prospect',
      {
        method: 'POST',
        body: JSON.stringify({ ...action.payload }),
        headers: { 'Content-Type': 'application/json;charset=UTF-8' },
      })
      .then((res) => res.json())
      .catch((err) => console.log(err));
    yield put(push('/'));
  } catch (e) {
    console.log(e);
  }
}

function* registerCientWatcher() {
  yield takeLatest(CLIENT_REGISTRATION_SUBMIT, registerCientWorker);
}

export default registerCientWatcher;
