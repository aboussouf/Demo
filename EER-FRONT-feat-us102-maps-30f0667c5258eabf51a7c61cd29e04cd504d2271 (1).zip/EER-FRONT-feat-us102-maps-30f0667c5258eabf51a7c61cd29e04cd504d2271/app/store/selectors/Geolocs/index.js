import { createSelector } from 'reselect';

const geolocsState = (state) => state.get('geolocs');

const makeSelectAgencesList = () => createSelector(
    geolocsState,
    (agenceState) => agenceState.agences.toJS()
);

const makeSelectCitiesList = () => createSelector(
    geolocsState,
    (refState) => refState.cities.toJS()
    
);

const makeSelectCountrysList = () => createSelector(
    geolocsState,
    (refState) => refState.countrys.toJS()
);


export {
    makeSelectAgencesList,
    makeSelectCitiesList,
    makeSelectCountrysList
};
