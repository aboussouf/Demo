import { createSelector } from 'reselect';

const selectIp = (state) => state.get('ip');

const makeSelectIp = () => createSelector(
  selectIp,
  (ipState) => ipState.ipAdress
);

export {
  makeSelectIp,
};
