import { createSelector } from 'reselect';

const prospectsState = (state) => state.get('prospects');

const makeSelectProspectsList = () => createSelector(
    prospectsState,
    (prosState) => (prosState.list ? prosState.list.toJS() : [])
);
export {
    makeSelectProspectsList,
};
