import { createSelector } from 'reselect';

const referentielState = (state) => state.get('referentiel');

const makeSelectProductsList = () => createSelector(
    referentielState,
    (refState) => refState.productsList.toJS()
);
const makeSelectCities = () => createSelector(
    referentielState,
    (refState) => refState.cities.toJS()
);
const makeSelectSelectedCity = () => createSelector(
    referentielState,
    (refState) => refState.selectedCity ? refState.selectedCity.toJS() : null
);

export {
    makeSelectProductsList,
    makeSelectCities,
    makeSelectSelectedCity,
};
