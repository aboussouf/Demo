import { createSelector } from 'reselect';

const stepsState = (state) => state.get('step');

const makeSelectStep = () => createSelector(
    stepsState,
    (stepState) => stepState.toJS()
);


export {
    makeSelectStep
};
