import React from 'react';
import { connect } from 'react-redux';
import TextField from 'material-ui/TextField';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';
import PropTypes from 'prop-types';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import { styles } from './styles';
import DatePicker from 'material-ui/DatePicker';
import TimePicker from 'material-ui/TimePicker/TimePicker';
import Calendar from 'material-ui/DatePicker/Calendar';
import {List, ListItem} from 'material-ui/List';

class ChoseRdv extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
       DateTimeFormat:global.Intl.DateTimeFormat,
       days:'',
       month:'',
       year:'',
       hour: '',
       date: '',
    };
    
    
  }
  
 /**
   * when a component will mount
   */

  componentWillMount(){

  }

  /**
   * when a component will unmount
   */
  componentWillUnmount(){

  }

  /**
   * catch error
   */
  componentDidCatch(error, info){

  }
  onchangeDatePiker(){

  }

  /**
   * handle on change calander
   */
  handleChangeDate = (event, date) => {

    const dateRdv =  date.getFullYear()+"-"+(date.getUTCMonth()<10?'0'+date.getUTCMonth():date.getUTCMonth())+"-"+ (date.getDate()<10?'0'+date.getDate():date.getDate());
    const dateParse = new Date(dateRdv);
    
    this.setState({days:  dateParse.toLocaleString('fr', {  weekday: 'long' }) } );
    this.setState({month:  date.getUTCMonth() +" "+dateParse.toLocaleString("fr", { month: "long" }) } );
    this.setState({year:  date.getFullYear() } );
    this.setState({date:  dateRdv });
  };

  /**
   * send date to parent component
   */
  validStep(){
    this.props.onValidateStep(this.state);
  }
  prevStep(){
    this.props.onPrevStep()
  }

  handleChangeTime = (event, date) => {
    const time =  ""+date.getHours()+"H"+date.getMinutes();
    this.setState({hour: time});
  };
   disableWeekends(date) {
    return date.getDate() === 11 || date.getDate() === 12 || date.getDay() === 0 || date.getDay() === 6;
  }

    render() {
      return (

        <div style={styles.displayFlex}>
              <div style={styles.marginLeft}>
                <div>
                  <Calendar id="dateRdv" 
                        format='MMM DD, YYYY hh:mm A'
                        firstDayOfWeek={1}
                        onClickDay={this.handleChangeDate.bind(this)}
                        shouldDisableDate={this.disableWeekends}            
                    
                         >
                  </Calendar>
                </div>
                <div style={styles.container.timePicker}>
                <TimePicker
                        format="24hr"
                        hintText="l'heure du rendez-vous"
                        id="timeRDV"
                        value={this.state.value12}
                        onChange={this.handleChangeTime}
                      />
                </div>
              </div>
              
          <div style={styles.marginLeftLabel}>
            <div> RENCONTRONS-NOUS</div>
            <div> CHOISISSEZ VOTRE AGENCE ET VOTRE RENDEZ-VOUS</div>
              <div id="monAgence">
                      <p>Mon Agence</p>
                      <p>{this.props.prospect.agence.name}</p>
                      <p>{this.props.prospect.agence.adresse}</p>
              </div>
              <div id="dateRDV">
                    <p>{this.state.days}</p>
                    <p>{this.state.month}</p>
                    <p>{this.state.year}</p>
              </div>
              <div id="dateRDV">
                    <p> {this.state.hour}</p>
              </div>
              <FlatButton label="RETOUR" 
                            primary={true} 
                            onClick={this.prevStep.bind(this)}
                            />
          <FlatButton label="PRENDRE RENDEZ-VOUS" 
                            primary={true} 
                            onClick={this.validStep.bind(this)}
                            />
          
          </div>
        
        </div>

      );
    }

  }

  ChoseRdv.propTypes = {
    onValidateStep: PropTypes.func.isRequired, 
    onPrevStep:  PropTypes.func.isRequired, 
    prospect: PropTypes.object.isRequired,
};

export default ChoseRdv;

