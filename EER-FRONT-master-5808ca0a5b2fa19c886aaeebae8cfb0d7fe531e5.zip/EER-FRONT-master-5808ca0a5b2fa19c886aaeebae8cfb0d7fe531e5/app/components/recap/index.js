import React from 'react';
import { connect } from 'react-redux';
import TextField from 'material-ui/TextField';
import { RadioButton, RadioButtonGroup } from 'material-ui/RadioButton';
import PropTypes from 'prop-types';
import Checkbox from 'material-ui/Checkbox';
import RaisedButton from 'material-ui/RaisedButton/RaisedButton';
import FlatButton from 'material-ui/FlatButton';
import { styles } from './styles';
import DatePicker from 'material-ui/DatePicker';
import TimePicker from 'material-ui/TimePicker/TimePicker';
import Calendar from 'material-ui/DatePicker/Calendar';
import {List, ListItem} from 'material-ui/List';

class Recap extends React.Component {

  constructor(props) {
    super(props);

    this.state = {};
    
    
  }
  
 /**
   * when a component will mount
   */

  componentWillMount(){

  }

  /**
   * when a component will unmount
   */
  componentWillUnmount(){

  }

  /**
   * catch error
   */
  componentDidCatch(error, info){

  }
  /**
   * send date to parent component
   */
  validStep(){
      this.props.onValidateStep(this.props.prospect);
    }

    handlePrevStep () {
      this.props.onPrevStep();
    }
  

    render() {
      return (
        <div >
            <div>
               <p>Nom :  {this.props.prospect.lastName}  </p> 
               <p>Prénom :  {this.props.prospect.firstName}</p>  
               <p>tele :  {this.props.prospect.tele}  </p>  
               <p>email :  {this.props.prospect.email}  </p>  
               <p>date Rendez-vous :  {this.props.prospect.dateRdv}  </p>
               <p>heure Rendez-vous :  {this.props.prospect.heureRdv}  </p> 
               <p>mon agence :  {this.props.prospect.agence.name}  </p>  
               <p>adresse agence :  {this.props.prospect.agence.adresse}  </p>   
            </div>
            <FlatButton label="RETOUR" 
                            primary={true} 
                            onClick={this.handlePrevStep.bind(this)}
                            />
          <FlatButton label="PRENDRE RENDEZ-VOUS" 
                            primary={true} 
                            onClick={this.validStep.bind(this)}
                            />  
        </div>
      );
    }

  }

  Recap.propTypes = {
    onValidateStep: PropTypes.func.isRequired,
    onPrevStep: PropTypes.func.isRequired,
    prospect: PropTypes.object.isRequired 
};

export default Recap;

