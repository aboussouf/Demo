import React from 'react';
import PropTypes from 'prop-types';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import DatePicker from 'material-ui/DatePicker';
import TextField from 'material-ui/TextField';
import TimePicker from 'material-ui/TimePicker';
import { connect }   from 'react-redux';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

import MapContainer from './MapContainer';
import { getAgencysByCitie } from '../../store/actions/Geolocs';
import { makeSelectAgencesList } from '../../store/selectors/Geolocs';
import FlatButton from 'material-ui/FlatButton/FlatButton';
import { styles } from './styles';

//import SearchBox from './SearchBox';

 class RDVContainer extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      citiesDefaultValue: 1,
      ville: '',
      quartier: '',
      agence: '',
    };
    this.props.getAgencys(1)

  }
  handleCitiesChange = (event, index, citiesDefaultValue) => {
    this.setState({citiesDefaultValue});
    this.props.getAgencys(citiesDefaultValue)
  }

   handleCitySelectionChange = (event, index) => {
    const selectedCity = this.props.cities[index];
    this.props.rdvInfos.selectedCity=selectedCity;
    
    console.log('selectedCity',selectedCity);
   // this.props.getCityAgences(selectedCity.idVille);
    if (!!selectedCity && selectedCity.idVille && !selectedCity.agences) {
      
    //  this.props.getCityAgences(selectedCity.id);
    }
    this.props.rdvInfosChange('selectedAgence', null); 
  }
  handleAgenceSelectionChange = (event, index) => {
    const selectedAgence = this.props.agences[index];
    this.props.rdvInfo.selectedAgence = selectedAgence;
    
    //this.props.rdvInfosChange('selectedAgence', this.props.rdvInfos.selectedCity.agences[index]);
    //this.props.rdvInfosChange('selectedAgence', selectedAgence);
    //this.props.agence = this.props.rdvInfos.selectedCity.agences[index];
    
    //this.props.onChange(event.target.value);
    this.props.onChange(rdvInfo.selectedAgence.idAgence);
    this.setState({
      agence: rdvInfo.selectedAgence.idAgence,
    });
    console.log('agenceId',this.state.agence);
    // Fin Ali
  }
  handleDateSelectionChange = (event, date) => {
    this.props.rdvInfosChange('selectedDate', date);
  }
  handleTimeSelectionChange = (event) => {
    this.props.rdvInfosChange('selectedTime', event.target.value);
  }

   /**
   * send date to parent component
   */
  validStep(){
    console.log('validStep')
    this.props.onValidateStep(this.state);
  }
   /**
   * prevent step
   */
  prevStep(){
    console.log('prevStep');
    this.props.onPrevStep(this.state);
  }

  render() {
    const rdvInfo = this.props.rdvInfos;
    const minDate = new Date();
    const maxDate = new Date();
    minDate.setHours(0, 0, 0, 0);
    maxDate.setMonth(maxDate.getMonth() + 1);
    maxDate.setHours(0, 0, 0, 0);
    return (
      <div>
        <div  >
        <h1> RENCONTRONS-NOUS </h1>
          <h1> Choisissez votre agence et votre rendez-vous : </h1>  
        
        <SelectField
            floatingLabelText="Ville"
            value={this.state.citiesDefaultValue}
            onChange={this.handleCitiesChange}
            maxHeight={400}
            fullWidth
          >
            {this.props.cities && this.props.cities
                                            .map( (city) => 
                                              <MenuItem value={city.idVille} key={`city_${city.idVille}`} primaryText={city.libelle} />
                                              )}
         </SelectField>


                                            
          <div>

          <div >
          <MapContainer  ref="map"
            google={this.props.google} 
            agences = {this.props.agences}
           >                         
          </MapContainer>
           </div>
          
          </div>

          {rdvInfo.selectedCity && rdvInfo.selectedCity.agences && rdvInfo.selectedCity.agences.length > 0 &&
            <SelectField
              floatingLabelText="Agences"
              value={rdvInfo.selectedAgence ? rdvInfo.selectedAgence.id : null}
              onChange={this.handleAgenceSelectionChange}
              maxHeight={200}
              fullWidth
            >
              {rdvInfo.selectedCity.agences.map((agence) => <MenuItem value={agence.id} key={`agence_${agence.id}`} primaryText={agence.adresse} />)}
            </SelectField>
          }
         
        </div>
        <div style={styles.floatRight}>
        <FlatButton label="Retour" 
                            primary={true} 
                            onClick={this.prevStep.bind(this)}
                            />
        <FlatButton label="Prendre Rendez-vous" 
                            primary={true} 
                            onClick={this.validStep.bind(this)}
                            />
        </div>
        
      </div>
    );
  }
}

RDVContainer.propTypes = {
  cities: PropTypes.array.isRequired,
  agences: PropTypes.array.isRequired,
  rdvInfos: PropTypes.object.isRequired,
  rdvInfosChange: PropTypes.func.isRequired,
  getCityAgences: PropTypes.func.isRequired,
  onPrevStep: PropTypes.func.isRequired, 
};


const mapStateToProps = (state) => ({
    agences: makeSelectAgencesList()(state),

  });
  
  const mapDispatchToProps = (dispath) => ({
    getAgencys: (payload) => { dispath(getAgencysByCitie(payload)); },
  });

  export default connect(mapStateToProps, mapDispatchToProps)(RDVContainer);

