import React, { Component } from 'react';
import PropTypes from 'prop-types';
import IdentityComponent from 'components/IdentityComponent';
import ProspectInfo from 'components/ProspectInfo'
import ChoseAgency from 'components/ChoseAgency'
import ProductChoiceComponent from 'components/ProductChoiceComponent';
import RDVContainer from 'containers/RDVContainer';
import { connect } from 'react-redux';
import { Step,Stepper,StepLabel} from 'material-ui/Stepper';
import FlatButton from 'material-ui/FlatButton';
import RaisedButton from 'material-ui/RaisedButton';
import Paper from 'material-ui/Paper';
import { makeSelectSelectedCity } from 'store/selectors/Referentiel';
import { styles } from './styles';
import {setProspect,saveProspect} from '../../store/actions/prospect'
import {getCities} from '../../store/actions/Geolocs'
import ChoseRdv from '../../components/ChoseRdv';
import Recap from '../../components/Recap';
import {makeSelectProspect } from '../../store/selectors/Prospect';

export class SignUpContainer extends Component {
  
  constructor(props) {
    super(props)
  }
  
  state = {
    identityFormValues: {
      cmdp: true,
      sexe: null,
      lastName: '',
      firstName: '',
      dateOfBirth: '',
      email: '',
      tele: '',
      part:true,
      prof:false,
    },
    selectedProductId: null,
    stepIndex: 0,
    rdvInformations: {
      selectedCity: null,
      selectedAgence: null,
      selectedDate: null,
      selectedTime: '',
    },
    nextProps: {
      selectedCity: null,
      selectedAgence: null,
      selectedDate: null,
      selectedTime: '',
    },
  }
  componentWillMount(){
  }
  componentWillReceiveProps = (nextProps) => {
    if (nextProps && nextProps.selectedCity) {
      this.rdvInfosChange('selectedCity', nextProps.selectedCity);
    }
  }
  onEventValFieldChange = (event, value) => {
    this.setState({
      ...this.state,
      identityFormValues: {
        ...this.state.identityFormValues,
        [event.target.name]: value,
      },
    });
  }

  /**
   * dispatch action to put info prospect to store
   * @param {*} prospect 
   */
  validStepInfoProspect (prospect)  {
    this.props.validStepOneStore({
      firstName: prospect.firstName,
      lastName: prospect.lastName,
      tele: prospect.tele,
      email: prospect.email,
      particularite: prospect.particularite,
      agence: this.props.prospect.agence
    })
    this.handleNextStep();
  }
  /**
   * dispatch action to put date && hour rdv to store
   * @param {*} prospect 
   */
  valideStepChoseRdv(rdvInfo){
      this.props.validStepOneStore({
        idProspect:0,
        firstName: this.props.prospect.firstName,
        lastName: this.props.prospect.lastName,
        tele: this.props.prospect.tele,
        email: this.props.prospect.email,
        typeProspect: this.props.prospect.particularite,
        boisson: "CAFE",
        dateRdv: rdvInfo.date,
        heureRdv: rdvInfo.hour,
        cmdp: 1,
        sexe: 1,
        agence: this.props.prospect.agence,
      })

      this.handleNextStep();
  }
  valideStepRDVContainer(){
    this.handleNextStep();
  }
  /**
   * dispatch action to put date && hour rdv to store
   * @param {*} prospect 
   */
  valideStepRecap (prospect){
      console.log('valideStepRecap :',prospect);
      this.props.persistProspect(prospect);
  }

  getStepContent = (stepIndex) => {
    switch (stepIndex) {
      case 0: return (<ProspectInfo 
                          onValidateStep={this.validStepInfoProspect.bind(this)}
                    />);
      case 1: return (<RDVContainer
                      cities={this.props.cities}
                      agences={this.props.agences}
                      rdvInfosChange={this.rdvInfosChange}
                      rdvInfos={this.state.rdvInformations}
                      getCityAgences={this.props.getCityAgences}
                      onPrevStep={this.handlePrevStep.bind(this)}
                      onValidateStep={this.valideStepRDVContainer.bind(this)}
              
              />);
                    
        case 2: return (<ChoseRdv 
                            onValidateStep={this.valideStepChoseRdv.bind(this)}
                            onPrevStep={this.handlePrevStep.bind(this)}
                            prospect={this.props.prospect}
                />);
        case 3: return (<Recap 
                            onValidateStep={this.valideStepRecap.bind(this)}
                            onPrevStep={this.handlePrevStep.bind(this)}
                            prospect={this.props.prospect}
                           
                /> );
                
      default: return "";
    }
  }
  handleNextStep = () => {
    const { stepIndex } = this.state;

    if (stepIndex < this.lastStepIndex) {
      this.setState({ stepIndex: stepIndex + 1 });
    }
    if (stepIndex === this.lastStepIndex) {
     // this.handleSubmit();
    }
  }
  handlePrevStep = () => {
    const { stepIndex } = this.state;

    if (stepIndex > 0) {
      this.setState({ stepIndex: stepIndex - 1 });
    }
  }
  handleSubmit = () => {
    this.props.onSubmit(this.state.identityFormValues);
  }
  productSelectionChange = (event, index, value) => {
    this.setState({
      ...this.state,
      selectedProductId: value,
    });
  }
  identityFieldChange = (event) => {
    this.onEventValFieldChange(event, event.target.value);
  }

 


  identityParticulariterClick = (event) => {
  
   this.state.identityFormValues.part=!this.state.identityFormValues.part;
  }
  rdvInfosChange = (field, value) => {
    this.setState({
      ...this.state,
      rdvInformations: {
        ...this.state.rdvInformations,
        [field]: value,
      },
    });
  }
  lastStepIndex = 3;

  render() {
    const { stepIndex } = this.state;
    return (
      <Paper style={styles.pageContainerStyle} zDepth={5} rounded={false}>
        <Stepper activeStep={stepIndex}>
          <Step>
            <StepLabel>{'Informations d\'identité'}</StepLabel>
          </Step>
          <Step>
            <StepLabel>{'Choix du produit'}</StepLabel>
          </Step>
          <Step>
            <StepLabel>{'Rendez-vous'}</StepLabel>
          </Step>
        </Stepper>
        {this.getStepContent(stepIndex)}
        
      </Paper>
    );
  }
}

SignUpContainer.propTypes = {
  products: PropTypes.array.isRequired,
  onSubmit: PropTypes.func.isRequired,
  getCityAgences: PropTypes.func.isRequired,
  cities: PropTypes.array.isRequired,
  countrys: PropTypes.array.isRequired,
};

const mapStateToProps = (state) => ({
  selectedCity: makeSelectSelectedCity()(state),
  selectedAgences: makeSelectSelectedCity()(state),
  prospect: makeSelectProspect()(state)
});

const mapDispatchToProps = (dispath) => ({
  validStepOneStore: (prospect) => { dispath(setProspect(prospect)); },
  persistProspect: (prospect) => { dispath(saveProspect(prospect)); },
});



export default connect(mapStateToProps, mapDispatchToProps)(SignUpContainer);
