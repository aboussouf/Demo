import React from 'react';
import PropTypes from 'prop-types';
import SignUpContainer from 'containers/SignUpContainer';
import { connect } from 'react-redux';
import { makeSelectProductsList, makeSelectCities } from 'store/selectors/Referentiel';
import {makeSelectAgencesList , makeSelectCitiesList,makeSelectCountrysList} from 'store/selectors/Geolocs';
import { registerClient } from 'store/actions/SignUp';
import { getCitiesList, getCityAgences } from 'store/actions/Referentiel';
import { getAgences, getCities,getCountrys } from 'store/actions/Geolocs'

export class SignUpPage extends React.Component {
  componentDidMount = () => {
   // this.props.getAgencesList();
    this.props.getCities();
  }
  getCityAgences = (cityId) => {
    this.getCityAgences(cityId);
  }
  render() {
    return (
      <SignUpContainer
        products={this.props.products}
        cities={this.props.cities}
        countrys={this.props.countrys}
        agences={this.props.agences}
        onSubmit={this.props.registerClientAction}
        getCityAgences={this.getCityAgences}
      />
    );
  }
}

SignUpPage.propTypes = {
  products: PropTypes.array.isRequired,
  cities: PropTypes.array.isRequired,
  registerClientAction: PropTypes.func.isRequired,
  getCitiesList: PropTypes.func.isRequired,
};

const mapStateToProps = (state) => ({
  products: makeSelectProductsList()(state),
  cities: makeSelectCitiesList()(state),
  agences:makeSelectAgencesList()(state),
  countrys:makeSelectCountrysList()(state),
});

const mapDispatchToProps = (dispath) => ({
  registerClientAction: (payload) => { dispath(registerClient(payload)); },
  getCityAgences: (payload) => { dispath(getCityAgences(payload)); },
  getCitiesList: () => { dispath(getCitiesList()); },
  getAgencesList: () => { dispath(getAgences()); },
  getCities: () => { dispath(getCities()); },
  getCountrys: () => { dispath(getCountrys()); },
});

export default connect(mapStateToProps, mapDispatchToProps)(SignUpPage);
