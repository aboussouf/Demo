export const CLIENT_REGISTRATION_SUBMIT = 'CLIENT_REGISTRATION_SUBMIT';

const registerClient = (informations) => ({
  type: CLIENT_REGISTRATION_SUBMIT,
  payload: informations,
});

export {
    registerClient,
};
