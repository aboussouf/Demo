/** 
 * created by nacim.issam
*/
export const GET_PROSPECT = 'GET_PROSPECT';
export const SET_PROSPECT = 'SET_PROSPECT';
export const SAVE_PROSPECT = 'SAVE_PROSPECT';

/** 
 * list of actions prospect
*/
const getProspect = () => ({
  type: GET_PROSPECT,
});
const setProspect = (prospect) => ({
  type: SET_PROSPECT,
  payload: prospect,
});
const saveProspect = (prospect) => ({
  type: SAVE_PROSPECT,
  payload: prospect,
});
/**
 * export all prospect actions
 */
export {
  getProspect,
  setProspect,
  saveProspect,
};
