import { fromJS } from 'immutable';
import { SET_PRODUCTS_LIST, SET_CITIES_LIST, SET_SELECTED_AGENCES } from 'store/actions/Referentiel';

/* const referentielInitState = fromJS({
  productsList: fromJS([]),
}); */

const referentielInitState = {
  productsList: fromJS([{
    id: 1,
    name: 'Epargne',
    description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam in ipsum arcu. Duis sed enim gravida, dapibus diam ut, varius nisl. Nullam sagittis placerat nisi quis accumsan. Etiam tincidunt eleifend elit, sed tincidunt velit consequat at. Sed nisl leo, luctus ut metus nec, ullamcorper suscipit lorem. Vivamus aliquet lectus lorem, in venenatis enim vehicula eu. Ut sed iaculis mauris. Mauris mollis accumsan pulvinar. Phasellus a enim venenatis, ultrices nisl sit amet, vehicula arcu. Phasellus accumsan mauris ut lacus suscipit, non faucibus odio consequat. Interdum et malesuada fames ac ante ipsum primis in faucibus. Aliquam dapibus sapien in enim mattis, eget imperdiet tortor imperdiet.',
    neededFiles: ['Cin'],
  }, {
    id: 2,
    name: 'Compte conjoint',
    description: 'Lorem Ipsum 2',
    neededFiles: ['Cin', 'Cin conjoint', 'Acte de mariage'],
  }, {
    id: 3,
    name: 'Code18 étudiant',
    description: 'Lorem Ipsum 3',
    neededFiles: ['Cin', 'Certificat de scolarité'],
  }]),
  cities: fromJS([{
    id: 7,
    name: 'Casahhhhhhhh',
    agences: [{
      id: 1,
      name: 'Nouacer',
    }, {
      id: 2,
      name: 'Ghandi',
    }, {
      id: 20,
      name: 'Sidi maarouf',
    }],
  }, {
    id: 46,
    name: 'Taza',
    agences: [{
      id: 3,
      name: 'Principale',
    }, {
      id: 4,
      name: 'Haut',
    }],
  }]),
  selectedCity: fromJS(null),
};

function referentielReducer(state = referentielInitState, action) {
  switch (action.type) {
    case SET_PRODUCTS_LIST:

      return ({
        ...state,
        productsList: fromJS(action.payload),
      });

    case SET_CITIES_LIST:

      return ({
        ...state,
        cities: fromJS(action.payload),
      });

    case SET_SELECTED_AGENCES: {

      const cityId = action.payload.cityId;
      const cityAgences = action.payload.agences;
      const citiesJs = state.cities.toJS();
      const cityIndex = citiesJs.findIndex((city) => cityId === city.id);
      return ({
        ...state,
        selectedCity: fromJS({
          ...citiesJs[cityIndex],
          agences: cityAgences,
        }),
      });

    }

    default:
      return state;
  }
}

export default referentielReducer;
