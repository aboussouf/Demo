import { takeLatest, put } from 'redux-saga/effects';
import {
  setProspectsList,
  getProspectsList,
  GET_PROSPECTS_LIST,
  DELETE_PROSPECT,
} from 'store/actions/Prospects';

function* getProspectsListWorker() {
  try {
    const list = yield fetch('http://10.85.12.107:8765/api/prospect/prospect')
            .then((res) => res.json())
            .catch((err) => console.log(err));
    yield put(setProspectsList(list));
  } catch (e) {
    console.log(e);
  }
}

function* getProspectsListWatcher() {
  yield takeLatest(GET_PROSPECTS_LIST, getProspectsListWorker);
}


function* deleteProspectWorker(action) {
  try {
    if (!action || !action.payload || !action.payload.id) {
      return;
    }
    yield fetch(`http://10.85.12.107:8765/api/prospect/prospect/${action.payload.id}`,
      {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json;charset=UTF-8' },
      });
    // .then((res) => res.json())
    // .catch((err) => console.log(err));
    yield put(getProspectsList());
  } catch (e) {
    console.log(e);
  }
}

function* deleteProspectWatcher() {
  yield takeLatest(DELETE_PROSPECT, deleteProspectWorker);
}

export {
  getProspectsListWatcher,
  deleteProspectWatcher,
};
