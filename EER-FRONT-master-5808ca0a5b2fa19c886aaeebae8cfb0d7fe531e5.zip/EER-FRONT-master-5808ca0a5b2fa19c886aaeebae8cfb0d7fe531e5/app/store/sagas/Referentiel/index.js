import { takeLatest, put } from 'redux-saga/effects';
import {
  setProductsList,
  GET_PRODUCTS_LIST,
  GET_CITIES_LIST,
  setCitiesList,
  GET_CITY_AGENCES,
  setSelectedCity,
} from 'store/actions/Referentiel';


function* getProductsListWorker() {
  try {
    const list = yield fetch('http://10.85.12.107/products/list')
            .then((res) => res.json())
            .catch((err) => console.log(err));
    yield put(setProductsList(list));
  } catch (e) {
    console.log(e);
  }
}

function* getProductsListWatcher() {
  yield takeLatest(GET_PRODUCTS_LIST, getProductsListWorker);
}

function* getCitiesWorker() {
  try {
    const cities = yield fetch('http://10.85.12.107:8762/api/geolocalisation/ville') // ('https://jsonplaceholder.typicode.com/posts')
                  .then((res) => res.json());
    yield put(setCitiesList(cities));
  } catch (e) {
    console.log(e);
  }
}

function* getCitiesWatcher() {
  yield takeLatest(GET_CITIES_LIST, getCitiesWorker);
}


function* getCityAgencesWorker(action) {
  try {
    const agences = yield fetch(`http://10.85.12.107:8762/api/geolocalisation/ville/${action.payload}/agences`)
                  .then((res) => res.json());
    if(!!agences) {
      yield put(setSelectedCity(action.payload, agences));
    }
  } catch (e) {
    console.log(e);
  }
}

function* getCityAgencesWatcher() {
  yield takeLatest(GET_CITY_AGENCES, getCityAgencesWorker);
}

export {
  getProductsListWatcher,
  getCitiesWatcher,
  getCityAgencesWatcher,
};
