import registerCientWatcher from 'store/sagas/SignUp';
import { getProductsListWatcher, getCitiesWatcher, getCityAgencesWatcher } from 'store/sagas/Referentiel';
import {getAgencesWatcher , getCitiesGeolocWatcher, getCountrysGeolocWatcher,getAgencyByCountryGeolocWatcher} from 'store/sagas/Geolocs';
import { getProspectsListWatcher, deleteProspectWatcher } from 'store/sagas/Prospects';
import {saveProspectsWatcher} from 'store/sagas/Prospect'; 
import { getAgencyByCitieGeolocWatcher } from './Geolocs';

export default [
  registerCientWatcher,
  getProductsListWatcher,
  getProspectsListWatcher,
  deleteProspectWatcher,
  getAgencesWatcher,
  getCitiesGeolocWatcher,
  getCitiesWatcher,
  getCountrysGeolocWatcher,
  getCityAgencesWatcher,
  saveProspectsWatcher,
  getAgencyByCountryGeolocWatcher,
  getAgencyByCitieGeolocWatcher,
];
