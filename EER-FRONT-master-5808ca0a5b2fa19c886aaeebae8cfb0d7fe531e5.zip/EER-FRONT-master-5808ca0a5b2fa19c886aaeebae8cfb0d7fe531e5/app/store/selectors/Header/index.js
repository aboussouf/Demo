import { createSelector } from 'reselect';

const selectHeader = (state) => state.get('header');

const makeSelectHeaderTitle = () => createSelector(
  selectHeader,
  (headerState) => headerState.get('headerTitle')
);

export {
  makeSelectHeaderTitle,
};
